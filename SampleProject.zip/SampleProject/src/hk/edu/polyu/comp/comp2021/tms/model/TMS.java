package hk.edu.polyu.comp.comp2021.tms.model;

public class TMS {

    public TMS(){}

}

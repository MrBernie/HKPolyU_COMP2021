package hk.edu.polyu.comp.comp2021.tms;

import hk.edu.polyu.comp.comp2021.tms.model.TMS;

public class Application {

    public static void main(String[] args){
        TMS tms = new TMS();
        // Initialize and run the system
    }

}
